// ============================================
// .autoreact — har aane wale message par pyara sa react (per bot number)
//   .autoreact on | off | status | set ❤️,🌹,✨
// Actual reacting happens in main.js (AUTO REACT block).
// ============================================
const { cmd } = require('../arslan');
const { updateUserConfigInMongoDB, getUserConfigFromMongoDB } = require('../lib/database');

const DEFAULT = '❤️,🩷,💖,💗,💕,🥰,😍,🌹,🌸,✨,💫,🦋,🤍,💜,😘,🫶,🌺,💝';

cmd({
    pattern: 'autoreact',
    alias: ['areact', 'autoreaction'],
    desc: 'Auto react to every incoming message',
    category: 'owner',
    react: '💖',
    filename: __filename
}, async (conn, mek, m, { args, reply, isOwner, botNumber }) => {
    if (!isOwner) return reply('❌ Ye command sirf owner ke liye hai.');
    const num = String(botNumber || '').replace(/\D/g, '');
    const sub = (args[0] || '').toLowerCase();

    if (sub === 'on' || sub === 'off') {
        await updateUserConfigInMongoDB(num, { AUTO_REACT: sub === 'on' ? 'true' : 'false' });
        return reply(`✅ Auto-react *${sub.toUpperCase()}* ho gaya.`);
    }
    if (sub === 'set') {
        const list = args.slice(1).join(' ').split(/[,\s]+/).filter(Boolean).join(',');
        if (!list) return reply('❌ Usage: .autoreact set ❤️,🌹,✨');
        await updateUserConfigInMongoDB(num, { AUTO_REACT_EMOJIS: list });
        return reply(`✅ Emojis set: ${list.split(',').join(' ')}`);
    }
    if (sub === 'reset') {
        await updateUserConfigInMongoDB(num, { AUTO_REACT_EMOJIS: '' });
        return reply(`✅ Default emojis wapas: ${DEFAULT.split(',').join(' ')}`);
    }
    let cfg = {};
    try { cfg = (await getUserConfigFromMongoDB(num)) || {}; } catch (e) {}
    return reply(
        `📊 *Auto-React*\n\n• Status: ${cfg.AUTO_REACT === 'true' ? '🟢 ON' : '🔴 OFF'}\n` +
        `• Emojis: ${(cfg.AUTO_REACT_EMOJIS || DEFAULT).split(',').join(' ')}\n\n` +
        `*Usage:*\n.autoreact on / off\n.autoreact set ❤️,🌹,✨\n.autoreact reset`
    );
});
