// commands/owner/install.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const config = require('../../../config');
const ui = require('../../utils/ui');

const INSTALLED_LOG = path.join(__dirname, '../../database/installed_plugins.json');

const getPrimaryOwner = () => String((config.OWNER_NUMBER && config.OWNER_NUMBER[0]) || '').replace(/[^0-9]/g, '');

const validCategories = [
  'admin', 'ai', 'anime', 'fun', 'general',
  'group', 'download', 'media', 'dev', 'owner', 'textmaker', 'utility', 'bug'
];

function gistToRawUrl(gistUrl) {
  try {
    const url = new URL(gistUrl);
    if (url.hostname === 'gist.github.com') {
      const pathParts = url.pathname.split('/').filter(p => p);
      if (pathParts.length >= 2) {
        const user = pathParts[0];
        const gistId = pathParts[1];
        return `https://gist.githubusercontent.com/${user}/${gistId}/raw`;
      }
    }
    return gistUrl;
  } catch { return gistUrl; }
}

function restartBot() {
  exec('pm2 restart all', (err) => {
    if (err) {
      console.log('PM2 not found, exiting process...');
      setTimeout(() => process.exit(0), 1000);
    }
  });
}

async function notifyPrimaryOwner(sock, pluginInfo, installerJid) {
  try {
    const manager = globalThis.ProBoySessionManager;
    const primarySock = manager?.getPrimarySock?.() || sock;
    if (!primarySock?.sendMessage) return;
    const who = String(installerJid || '').split('@')[0] || 'unknown';
    const text = [
      '🧩 *Plugin Installed*',
      '',
      `👤 By: ${who}`,
      `🧾 Name: ${pluginInfo?.name || 'unknown'}`,
      `📁 Category: ${pluginInfo?.category || 'unknown'}`,
      pluginInfo?.description ? `📝 Description: ${pluginInfo.description}` : null,
      pluginInfo?.usage ? `⚙️ Usage: ${pluginInfo.usage}` : null,
      '',
      `🕒 ${new Date().toLocaleString()}`
    ].filter(Boolean).join('\n');
    const owner = getPrimaryOwner();
    if (!owner) return;
    await primarySock.sendMessage(`${owner}@s.whatsapp.net`, { text });
  } catch {}
}

// ─── New Helper: save installed plugin record ──────
function saveInstalledPlugin(pluginInfo, installerJid) {
  try {
    if (!fs.existsSync(INSTALLED_LOG)) fs.writeFileSync(INSTALLED_LOG, '[]');
    const data = JSON.parse(fs.readFileSync(INSTALLED_LOG));
    const relativePath = path.join('commands', pluginInfo.category, `${pluginInfo.name}.js`).replace(/\\/g, '/');
    // Remove duplicate if exists
    const filtered = data.filter(p => p.path !== relativePath);
    filtered.push({
      path: relativePath,
      name: pluginInfo.name,
      category: pluginInfo.category,
      by: String(installerJid || '').split('@')[0] || 'unknown',
      ts: Date.now()
    });
    fs.writeFileSync(INSTALLED_LOG, JSON.stringify(filtered, null, 2));
    console.log(`[INSTALL] Registered: ${relativePath}`);
  } catch (e) {
    console.error('[INSTALL] Failed to save log:', e.message);
  }
}

module.exports = {
  name: 'install',
  aliases: ['plugin', 'addplugin'],
  category: 'dev',
  description: 'Install a plugin from a GitHub Gist URL or by replying to a plugin file',
  usage: '.install [-r|--restart] <gist_url>  OR  reply to a .js file with .install [-r]',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      let autoRestart = false;
      const filteredArgs = args.filter(arg => {
        if (arg === '-r' || arg === '--restart') {
          autoRestart = true;
          return false;
        }
        return true;
      });

      let content = null;
      let method = null;

      if (filteredArgs.length > 0) {
        const inputUrl = filteredArgs[0].trim();
        const rawUrl = gistToRawUrl(inputUrl);
        method = 'url';
        await extra.react('⏳');
        const response = await axios.get(rawUrl, {
          timeout: 15000,
          headers: { 'User-Agent': 'ProBoy-MD-Installer' }
        });
        content = response.data;
      } else {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted) {
          return extra.reply('❌ Please reply to a `.js` file or provide a Gist URL.\n' + this.usage);
        }
        const doc = quoted.documentMessage;
        if (!doc) {
          return extra.reply('❌ Quoted message is not a file. Please reply to a `.js` plugin file.');
        }
        const fileName = doc.fileName || '';
        if (!fileName.endsWith('.js')) {
          return extra.reply('❌ File must be a `.js` JavaScript file.');
        }
        method = 'reply';
        await extra.react('⏳');
        const buffer = await downloadMediaMessage(
          { key: msg.key, message: quoted },
          'buffer',
          {},
          { logger: undefined, reuploadRequest: sock.updateMediaMessage }
        );
        content = buffer.toString('utf8');
      }

      if (!content) throw new Error('Failed to retrieve plugin content.');

      const pluginInfo = parsePlugin(content);
      if (!pluginInfo.name) throw new Error('Could not determine plugin name.');
      if (!pluginInfo.category || !validCategories.includes(pluginInfo.category)) {
        throw new Error(`Invalid or missing category. Allowed: ${validCategories.join(', ')}`);
      }

      const targetDir = path.join(__dirname, '..', pluginInfo.category);
      const targetFile = path.join(targetDir, `${pluginInfo.name}.js`);
      if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
      fs.writeFileSync(targetFile, content, 'utf8');

      try {
        delete require.cache[require.resolve(targetFile)];
        require(targetFile);
      } catch (loadErr) {
        fs.unlinkSync(targetFile);
        throw new Error(`Plugin failed to load: ${loadErr.message}`);
      }

      // ── Register the installed plugin ──
      saveInstalledPlugin(pluginInfo, extra.sender);

      let hotLoaded = false;
      try {
        // register the new command right away — no restart needed
        const loader = require('../../zzz-ported-commands-loader');
        hotLoaded = loader.registerPortedFile(targetFile, pluginInfo.category) === true;
        const installed = require(targetFile);
        if (hotLoaded && installed && typeof installed.init === 'function') {
          try { await installed.init(sock); } catch {}
        }
      } catch {}

      const details = [
        '✅ Plugin installed successfully!',
        `📁 Category: ${pluginInfo.category}`,
        `📄 File: ${pluginInfo.name}.js`,
        `🔖 Command: ${config.PREFIX || '.'}${pluginInfo.name}`
      ];
      if (pluginInfo.aliases?.length) details.push(`🔁 Aliases: ${pluginInfo.aliases.map(a => `${config.PREFIX || '.'}${a}`).join(', ')}`);
      if (pluginInfo.description) details.push(`📝 ${pluginInfo.description}`);
      if (pluginInfo.usage) details.push(`⚙️ Usage: ${pluginInfo.usage}`);

      const flags = [];
      if (pluginInfo.ownerOnly) flags.push('👑 Owner only');
      if (pluginInfo.modOnly) flags.push('🛡️ Mod only');
      if (pluginInfo.groupOnly) flags.push('👥 Group only');
      if (pluginInfo.privateOnly) flags.push('💬 Private only');
      if (pluginInfo.adminOnly) flags.push('🛡️ Admin only');
      if (pluginInfo.botAdminNeeded) flags.push('🤖 Bot admin needed');
      if (flags.length) details.push(`🚩 Flags: ${flags.join(' · ')}`);

      if (autoRestart) {
        details.push('♻️ Auto‑restarting now...');
        await sock.sendMessage(extra.from, { text: ui.box('Plugin', details, `🕒 ${new Date().toLocaleString()}`) }, { quoted: msg });
        await extra.react('✅');
        await notifyPrimaryOwner(sock, pluginInfo, extra.sender);
        restartBot();
      } else {
        if (hotLoaded) details.push('✅ Loaded (no restart needed).');
        else details.push('🔄 Restart required to load.');
        await sock.sendMessage(extra.from, { text: ui.box('Plugin', details, `🕒 ${new Date().toLocaleString()}`) }, { quoted: msg });
        await extra.react('✅');
        await notifyPrimaryOwner(sock, pluginInfo, extra.sender);
      }

    } catch (error) {
      console.error('Install error:', error.message);
      let errorMsg = '❌ Installation failed: ';
      if (error.response) errorMsg += `HTTP ${error.response.status} – ${error.response.statusText}`;
      else errorMsg += error.message;
      await extra.reply(errorMsg);
      await extra.react('❌');
    }
  }
};

function parsePlugin(content) {
  const info = {};
  const exportMatch = content.match(/module\.exports\s*=\s*({[\s\S]*?})/);
  if (!exportMatch) return info;
  const objStr = exportMatch[1];
  const extractString = (key) => {
    const regex = new RegExp(`${key}\\s*:\\s*['"]([^'"]+)['"]`);
    const match = objStr.match(regex);
    return match ? match[1] : null;
  };
  const extractBoolean = (key) => {
    const regex = new RegExp(`${key}\\s*:\\s*(true|false)`);
    const match = objStr.match(regex);
    return match ? match[1] === 'true' : false;
  };
  const extractArray = (key) => {
    const regex = new RegExp(`${key}\\s*:\\s*\\[([\\s\\S]*?)\\]`);
    const match = objStr.match(regex);
    if (!match) return [];
    const arrStr = match[1];
    const items = [];
    const itemRegex = /['"]([^'"]+)['"]/g;
    let itemMatch;
    while ((itemMatch = itemRegex.exec(arrStr)) !== null) items.push(itemMatch[1]);
    return items;
  };
  info.name = extractString('name');
  info.category = extractString('category');
  info.description = extractString('description');
  info.usage = extractString('usage');
  info.aliases = extractArray('aliases');
  info.ownerOnly = extractBoolean('ownerOnly');
  info.modOnly = extractBoolean('modOnly');
  info.groupOnly = extractBoolean('groupOnly');
  info.privateOnly = extractBoolean('privateOnly');
  info.adminOnly = extractBoolean('adminOnly');
  info.botAdminNeeded = extractBoolean('botAdminNeeded');
  return info;
}
